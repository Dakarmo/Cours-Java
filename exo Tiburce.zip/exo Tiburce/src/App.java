

import etudiant.test.Address;
import etudiant.test.Person;
import etudiant.test.Programeur;

public class App {
    
    public static void main(String[] args) {
        Address add = new Address("Bénin", "Abomey-Calavi", "Lobozounkpa");
        Person augustin = new Person("KOUDJIWAN", "Kodjo Augustin", 32, add);
        augustin.presente();
        
        Programeur etudiant = new Programeur();
        Programeur etudiant1 = new Programeur();
    }
}
