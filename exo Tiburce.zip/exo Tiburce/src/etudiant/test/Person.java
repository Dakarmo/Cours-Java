package etudiant.test;

public class Person extends Object{
    
    private String firstName = "Alice";
    private String lastName;
    private int hold;
    public static int feetNumber;
    private Address add;
    private String username;

    {
        username = "John Doe";
    }

    public String getFirstName() {
       return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public int getHold() {
        return hold;
    }

    public void setFirstName(String firstname) {
        firstName = firstname;
    }

    public void setLastName(String lastname) {
        lastName = lastname;
    }

    public void setHold(int age) {
        hold = age;
    }

    public Person() {

    }

    public Person(String firstname) {
        firstName = firstname;
    }

    public Person(String firstname, String lastname) {
        firstName = firstname;
        lastName = lastname;
    }

    public Person(String firstname, String lastname, int age, Address add) {
        System.out.println("appel du constructeur Person");
        this.firstName = firstname;
        this.lastName = lastname;
        this.hold = age;
        this.add = add;
    }

     public void presente() {
        System.out.println("Je m'appelle " + this.firstName + " " + this.lastName + ". J'ai " + this.hold + " ans et j'habite à " + this.add.getVille());
    }
    

    @Override
    public String toString() {
        //return firstName + lastName + hold;
        return " Bonjour " + this.getFirstName() + " " + this.getLastName() + ", vous avez " + getHold();
    }
    
    static {
        System.out.println("méthode static");
    }



    /*public static void main(String[] args) {
        //toto
        Person toto = new Person("toto", "Alitoto", 30);
        System.out.println(toto);

        System.out.println("=================");

        Person person2 = new Person("to", "toto", 20);
        System.out.println(person2);
    }*/
}
