package etudiant.test;

public class Programeur extends Person {

    public Programeur() {
        super();
        System.out.println("constructeur de Programmeur !");
    }

    static {
        System.out.println("Block statique");
    }
    {
        System.out.println("Block 1");
    }

    @Override
    public void presente() {
            //System.out.println("Je suis une personne !");
    }

    {
        System.out.println("Block 2");
    }
    public static void main(String[] args) {
        Programeur foo = new Programeur();
        foo.presente();
    }

    {
        System.out.println("Block 3");
    }
}
