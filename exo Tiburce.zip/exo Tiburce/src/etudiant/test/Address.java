package etudiant.test;

public class Address {
    private String pays;
    private String ville;
    private String quartier;

    public Address(String pays, String ville, String quartier) {
        this.pays = pays;
        this.ville = ville;
        this.quartier = quartier;
    }

    public String showAddress() {
        return "j'habtide à " + this.ville + " (" + this.pays + ")";
    }

    public String getPays() {
        return pays;
    }

    public void setPays(String pays) {
        this.pays = pays;
    }

    public String getVille() {
        return ville;
    }

    public void setVille(String ville) {
        this.ville = ville;
    }

    public String getQuartier() {
        return quartier;
    }

    public void setQuartier(String quartier) {
        this.quartier = quartier;
    }

    
}