package etudiant.modelisation;

public class Segment {
    private int  extr1;
    private int  extr2;

    public Segment(int x, int y) {
        extr1 = x;
        extr2 = y;
    }

}
